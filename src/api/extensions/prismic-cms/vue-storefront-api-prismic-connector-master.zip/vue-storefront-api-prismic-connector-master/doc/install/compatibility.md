# Compatibility:

### Vue Storefront API - Prismic Connector compatibility with Vue Storefront API:

Vue Storefront API - Prismic Connector is compatible with:

| Vue Storefront API - Prismic Connector Version | Vue Storefront API Version |
|------------------------------------------------|----------------------------|
| >= 1.0.0                                       | >= 1.6.0                   |

##### [> Back to summary](../summary.md)
