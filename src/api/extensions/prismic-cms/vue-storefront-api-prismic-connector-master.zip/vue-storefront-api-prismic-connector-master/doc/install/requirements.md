# Requirements:

### Vue Storefront API - Prismic Connector requirements for Vue Storefront - Prismic Connector:

Vue Storefront API - Prismic Connector requires:

| Vue Storefront API - Prismic Connector Version | Vue Storefront - Prismic Connector Version |
|------------------------------------------------|--------------------------------------------|
| >= 1.0.0                                       | >= 1.0.0                                   |

##### [> Back to summary](../summary.md)
